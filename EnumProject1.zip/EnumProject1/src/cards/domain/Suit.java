package cards.domain;

public enum Suit {
	SPADES,CLUBS,HEARTS,DIAMONDS
	
}


/*
  		final static	Suit SPADES=new Suit();
  
  */
